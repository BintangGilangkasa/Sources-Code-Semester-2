-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2024 at 09:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_indomaret`
--

-- --------------------------------------------------------

--
-- Table structure for table `cabang`
--

CREATE TABLE `cabang` (
  `Id_Cabang` int(20) NOT NULL,
  `Nama_Cabang` varchar(20) NOT NULL,
  `Alamat_Cabang` varchar(20) NOT NULL,
  `Kota` varchar(20) NOT NULL,
  `Provinsi` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cabang`
--

INSERT INTO `cabang` (`Id_Cabang`, `Nama_Cabang`, `Alamat_Cabang`, `Kota`, `Provinsi`) VALUES
(231, 'indomaret salatiga', 'tingkir', 'salatiga', 'jawa tengah'),
(232, 'indomaret wonosegoro', 'wonosegoro', 'boyolali', 'jawa tengah');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_kerja`
--

CREATE TABLE `jadwal_kerja` (
  `Id_Jadwal` int(11) NOT NULL,
  `Id_Karyawan` int(11) NOT NULL,
  `Tanggal` date NOT NULL,
  `Shift` enum('pagi','siang','malam') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal_kerja`
--

INSERT INTO `jadwal_kerja` (`Id_Jadwal`, `Id_Karyawan`, `Tanggal`, `Shift`) VALUES
(421, 121, '2025-01-10', 'pagi'),
(422, 122, '2025-01-10', 'siang');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `Id_karyawan` int(11) NOT NULL,
  `Nama` varchar(150) NOT NULL,
  `Alamat` varchar(20) NOT NULL,
  `Nomor_Telepon` varchar(20) NOT NULL,
  `Tanggal_Lahir` date NOT NULL,
  `Jabatan` varchar(20) NOT NULL,
  `Tanggal_Masuk_Kerja` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`Id_karyawan`, `Nama`, `Alamat`, `Nomor_Telepon`, `Tanggal_Lahir`, `Jabatan`, `Tanggal_Masuk_Kerja`) VALUES
(121, 'Andi Wildan', 'juranggunting, salat', '081344455566', '2004-06-10', 'kepala cabang', '2025-01-10'),
(122, 'bintang gilangkasa', 'cepoko, nganjuk', '081445556667', '2004-07-11', 'kasir', '2025-01-10');

-- --------------------------------------------------------

--
-- Table structure for table `penilaian_kinerja`
--

CREATE TABLE `penilaian_kinerja` (
  `Id_Penilaian` int(11) NOT NULL,
  `Id_Karyawan` int(11) NOT NULL,
  `Tanggal_Penilaian` date NOT NULL,
  `Skor_Kinerja` int(11) NOT NULL,
  `Catatan_penilaian` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penilaian_kinerja`
--

INSERT INTO `penilaian_kinerja` (`Id_Penilaian`, `Id_Karyawan`, `Tanggal_Penilaian`, `Skor_Kinerja`, `Catatan_penilaian`) VALUES
(521, 121, '2030-01-10', 10, 'rajin'),
(522, 122, '2030-01-10', 9, 'disiplin');

-- --------------------------------------------------------

--
-- Table structure for table `penugasan`
--

CREATE TABLE `penugasan` (
  `Id_Penugasan` int(11) NOT NULL,
  `Id_Karyawan` int(11) NOT NULL,
  `Id_Cabang` int(11) NOT NULL,
  `Tanggal_Mulai` date NOT NULL,
  `Tanggal_Selesai` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penugasan`
--

INSERT INTO `penugasan` (`Id_Penugasan`, `Id_Karyawan`, `Id_Cabang`, `Tanggal_Mulai`, `Tanggal_Selesai`) VALUES
(321, 121, 231, '2025-01-10', '2030-01-10'),
(322, 122, 232, '2025-01-10', '2030-01-10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cabang`
--
ALTER TABLE `cabang`
  ADD PRIMARY KEY (`Id_Cabang`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`Id_karyawan`);

--
-- Indexes for table `penugasan`
--
ALTER TABLE `penugasan`
  ADD PRIMARY KEY (`Id_Penugasan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
